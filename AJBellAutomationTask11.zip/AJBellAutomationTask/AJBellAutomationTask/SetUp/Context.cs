﻿using BoDi;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;


namespace AJBellAutomationTask.SetUps
{
    public class Context
    {

        public IObjectContainer _objectContainer;
        private IWebDriver _driver;
        private String baseUrl = "https://www.investcentre.co.uk";


        public Context(IObjectContainer objectContainer)
        {
            _objectContainer = objectContainer;
            _driver = new ChromeDriver();
            _objectContainer.RegisterInstanceAs<IWebDriver>(_driver);
        }

        public void LoadAJBellWebsiteApplication(string urlText)
        {
            if (urlText == "ajbell-funds-three-years") 
            {
                _driver.Navigate().GoToUrl(baseUrl + "/" + urlText);
            }
            else
            {
                _driver.Navigate().GoToUrl(baseUrl);
            }
                _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);
                _driver.Manage().Window.Maximize();
            
        }

        public void ShutDownAJBellWebsiteApplication()
        {
            _driver.Quit();
            _driver.Dispose();
        }


    }
}