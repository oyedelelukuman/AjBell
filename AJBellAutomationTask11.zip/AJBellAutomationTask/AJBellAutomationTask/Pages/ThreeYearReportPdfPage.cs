﻿using OpenQA.Selenium;
using System.Linq;

namespace AJBellAutomationTask.Pages
{
    public class ThreeYearReportPdfPage
    {
      
            private IWebDriver _driver;

            public ThreeYearReportPdfPage(IWebDriver driver)
            {
                _driver = driver;
            }
        By popup = By.Id("gateway-adviser");
        By findMore = By.Id("banner");

        public void CloseAlertPopUp()
        {

            _driver.FindElement(popup).Click();

        }
        public void ClickOnFindMore()
        {

            _driver.FindElement(findMore).Click();

        }
        public void DownloadThreeYearReport(string downloadThreeYearReport)
        {
            _driver.FindElement(By.LinkText(downloadThreeYearReport)).Click();
        }

        public string GetChildWindowTitle()
        {
            var newWindow = _driver.SwitchTo().Window(_driver.WindowHandles.Last());
            return newWindow.Url;
        }

    }
}
