﻿using OpenQA.Selenium;

namespace AJBellAutomationTask.Pages
{
    public class AdviserRegistrationValidationPage
    {
    
      
            private IWebDriver _driver;

        public AdviserRegistrationValidationPage(IWebDriver driver)
        {
            _driver = driver;

        }
        By registration = By.XPath("//*[@id='inner-wrap']/div[3]/header/div[1]/div/div[2]/nav[2]/ul/li[1]/a");
        By headerOneText = By.XPath("//h1");
        By continueButton = By.CssSelector("#AdviserRegsitration_Login");
        By errorMessageText = By.XPath("/html/body/div[1]/div/form/div[1]/div[2]/span");
        By enterRefNumber = By.Id("FSRNumber_TextBox");

        public void ClickOnRegistration()
        {
            _driver.FindElement(registration).Click();
        }
        public string PageHeaderOneText()
        {
            return _driver.FindElement(headerOneText).Text;
        }
        public void ClickOnContinue()
        {
            _driver.FindElement(continueButton).Click();
        }
        public string GetErrorMessageText()
        {
            return _driver.FindElement(errorMessageText).Text;
        }


        public void EnterReferenceNumber(string refNumber)
        {
            _driver.FindElement(enterRefNumber).SendKeys(refNumber);
        }
        

    }
}
