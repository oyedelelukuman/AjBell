﻿using AJBellAutomationTask.Pages;
using AJBellAutomationTask.SetUps;
using NUnit.Framework;
using System.Threading;
using TechTalk.SpecFlow;

namespace AJBellAutomationTask.StepDefinitions
{
    [Binding]
    public class ThreeYearReportPdfStep
    {
        Context _context;
        ThreeYearReportPdfPage _threeYearReportPdfPage;

        public ThreeYearReportPdfStep(Context context, ThreeYearReportPdfPage threeYearReportPdfPage)
        {
            _context = context;
            _threeYearReportPdfPage = threeYearReportPdfPage;

        }


        [Given(@"I navigate to '(.*)' investcentre website")]
        public void GivenINavigateToInvestcentreWebsite(string urlText)
        {
            _context.LoadAJBellWebsiteApplication(urlText);
            _threeYearReportPdfPage.CloseAlertPopUp();
        }


        [Given(@"I select on '(.*)' button from '(.*)' gadget")]
    
        public void GivenISelectOnAButtonFromGadget(string p0, string p1)
        {
            _threeYearReportPdfPage.ClickOnFindMore();
        }

        [When(@"I click '(.*)' button")]
        public void WhenIClickButton(string downloadThreeYearReport)
        {
            _threeYearReportPdfPage.DownloadThreeYearReport(downloadThreeYearReport);
        }

        [Then(@"I will validate the '(.*)' is displayed in new window")]
        public void ThenIWillValidateThePDFIsDisplayedInNewWindow(string expectedPageTitle)
        {
            Thread.Sleep(3000);
            Assert.That(_threeYearReportPdfPage.GetChildWindowTitle(), Does.EndWith(expectedPageTitle));
        }

        [AfterScenario]

        public void ShutdownApplication()
        {
            _context.ShutDownAJBellWebsiteApplication();
        }

    }
}

