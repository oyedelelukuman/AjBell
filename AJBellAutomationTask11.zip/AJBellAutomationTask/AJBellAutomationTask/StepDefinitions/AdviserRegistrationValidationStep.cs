﻿using AJBellAutomationTask.SetUps;
using AJBellAutomationTask.Pages;
using TechTalk.SpecFlow;
using NUnit.Framework;
using AJBellAutomationTask.DataHelpers;
using System.Threading;

namespace AJBellAutomationTask.StepDefinitions
{
    [Binding]
    public class AdviserRegistrationValidationStep
    {
        Context _context;
        AdviserRegistrationValidationPage _adviserRegistrationValidationPage;
        RandomCharaterHelpers _randomCharaterHelpers;
        public AdviserRegistrationValidationStep(Context context, AdviserRegistrationValidationPage adviserRegistrationValidationPage, RandomCharaterHelpers randomCharaterHelpers)
        {
            _context = context;
            _adviserRegistrationValidationPage = adviserRegistrationValidationPage;
            _randomCharaterHelpers = randomCharaterHelpers;
        }


        [Given(@"I select the 'Register' icon in top navigation bar")]
        [When(@"I select the ‘Register’ icon in top navigation bar")]
            public void WhenISelectTheRegisterIconInTopNavigationBar()
            {
            _adviserRegistrationValidationPage.ClickOnRegistration();
        }

            [Then(@"I will validate the (.*) page is displayed")]
            public void ThenIWillValidateTheAdviserRegistrationPageIsDisplayed(string pageHeaderOneText)
            {
            Assert.AreEqual(_adviserRegistrationValidationPage.PageHeaderOneText(), pageHeaderOneText);
            }


        [When(@"I click on Continue")]
        public void WhenIClickOnContinue()
        {
            _adviserRegistrationValidationPage.ClickOnContinue();
        }

        [Then(@"I will validate the error message is '(.*)'")]
        public void ThenIWillValidateTheErrorMessageIs(string expectedErrorMessage)
        {
            Thread.Sleep(3000);
            Assert.AreEqual(_adviserRegistrationValidationPage.GetErrorMessageText(), expectedErrorMessage);
        }
       
        [Given(@"I enter a random character to the '(.*)' field")]
        public void GivenIEnterARandomCharacterToTheField(string p0)
        {
            _adviserRegistrationValidationPage.EnterReferenceNumber(_randomCharaterHelpers.RandomCharacterdata());
        }

        [AfterScenario]

        public void ShutdownApplication()
        {
            _context.ShutDownAJBellWebsiteApplication();
        }
    }

}
