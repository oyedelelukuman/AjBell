﻿using System;


namespace AJBellAutomationTask.DataHelpers
{
    public class RandomCharaterHelpers
    {
        public string RandomCharacterdata()
        {
            Random rnd = new Random();
           char randomChar = (char)rnd.Next('a', 'z');
            return randomChar.ToString();
        }
    }
}
